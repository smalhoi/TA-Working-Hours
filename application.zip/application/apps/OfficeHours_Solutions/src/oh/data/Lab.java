/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oh.data;

/**
 *
 * @verson pre-final
 */
public class Lab extends Recitation{

    public Lab(String section, String day_time, String location, String ta_1, String ta_2) {
        super(section, day_time, location, ta_1, ta_2);
    }
    
}
