package oh.data;

/**
 *
 * @verson final
 */
public enum TAType {
    All,
    Graduate,
    Undergraduate
}